const allowedOrigins = [
    "https://masteko-asa.netlify.app",
    "http://localhost:5173",
    "https://masteko-property-kti.netlify.app",
    "https://property-new.netlify.app",
    "https://property-n.kiaantechnology.com",
    "https://www.property-n.kiaantechnology.com",
    "https://property-mastekocomplete.netlify.app",
    "http://masteko-pm.ca",
    "https://masteko-pm.ca"
];

module.exports = allowedOrigins;
