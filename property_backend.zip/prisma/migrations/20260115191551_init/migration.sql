-- AlterTable
ALTER TABLE `ticket` ADD COLUMN `category` VARCHAR(191) NULL;
